# username.github.io

# Usage
Fork the repository and than rename the repository by usrname.github.com.

# Update
If you want to update the site, you had better update files(index.md and publication.md) online, than visit 'username.github.io' URL to ensure the result you want.
## update Homepage
Updata  the fill called index.md. Most of this file is written in markdown language. Only part of the team members use html language.
Markdown language is easy to learn and use. For the part of the team members, we just need to imitate similar structures. The images of the team members is in the '/picture'. If you want to update your own image，use the photo of same name, or update the fill called "_layouts/default.html".

## update Publications
Updata  the fill called publiction.md.
